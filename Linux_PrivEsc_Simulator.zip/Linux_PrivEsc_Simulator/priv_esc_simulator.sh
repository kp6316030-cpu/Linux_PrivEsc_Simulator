#!/bin/bash

echo "========================================"
echo " Linux Privilege Escalation Simulator"
echo " Detection-Only | No Exploitation"
echo "========================================"
echo ""

echo "[+] Collecting System Information..."
echo "User        : $(whoami)"
echo "User ID     : $(id)"
echo "Hostname    : $(hostname)"
echo "Kernel Info : $(uname -a)"
echo
echo "[+] Scanning for SUID Binaries..."
find / -perm -4000 -type f 2>/dev/null | head -20
echo "[!] Note: Only listing sample results (simulation)"
echo

echo "[+] Scanning for SGID Binaries..."
find / -perm -2000 -type f 2>/dev/null | head -20
echo "[!] Note: Only listing sample results (simulation)"
echo

echo "[+] Checking for GTFOBins-Compatible Binaries..."

GTFO_BINS=("find" "vim" "awk" "perl" "python" "bash" "nmap")

for bin in "${GTFO_BINS[@]}"
do
    which $bin >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "[!] Potential GTFOBins Binary Found: $bin"
    fi
done

echo "[!] These binaries are dangerous only if misconfigured"
echo

echo "[+] Checking for World-Writable Files (Sample)..."
find / -writable -type f 2>/dev/null | head -10
echo "[!] Sample output shown (simulation)"
echo

echo "[+] Checking Critical System File Permissions..."
ls -l /etc/passwd
ls -l /etc/shadow
echo

echo "[+] Checking Sudo Permissions..."
sudo -l 2>/dev/null
echo "[!] Review NOPASSWD entries manually"
echo

echo "[+] Enumerating Cron Jobs..."
crontab -l 2>/dev/null
ls -la /etc/cron* 2>/dev/null | head -20
echo "[!] Writable cron scripts may lead to escalation"
echo

echo "[+] Checking System Services (Sample)..."
systemctl list-units --type=service | head -15
echo "[!] Services running as root must be carefully configured"
echo

echo "[+] Checking Kernel Version..."
uname -r
echo "[!] Outdated kernels may contain privilege escalation vulnerabilities"
echo

echo "========================================"
echo " Simulation Completed"
echo " No Exploitation Performed"
echo " Review results for potential risks"
echo "========================================"
