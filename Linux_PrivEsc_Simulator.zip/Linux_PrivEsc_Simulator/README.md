\# Linux Privilege Escalation Automation Toolkit (Simulation)



\## Description

This project is a detection-only simulation toolkit that identifies potential Linux privilege escalation vulnerabilities caused by system misconfigurations.



\## Features

\- SUID / SGID binary detection

\- Weak file and directory permission checks

\- Misconfigured services and sudo rules

\- Cron job vulnerability analysis

\- Kernel version analysis

\- No real exploitation performed



\## Tools Used

\- Linux (Ubuntu / Kali)

\- Bash scripting

\- Linux system commands

\- draw.io for diagrams



\## Usage

```bash

chmod +x priv\_esc\_simulation.sh

./priv\_esc\_simulation.sh

